package com.example.myapplication;
// Clase contacto para listaContactos
public class Contacto {
    private int imagen;
    private String nombre;
    private String anio;

    public Contacto(int imagen, String nombre, String anio) {
        this.imagen = imagen;
        this.nombre = nombre;
        this.anio = anio;
    }


    public String getNombre() {
        return nombre;
    }

    public String getAnio() {
        return anio;
    }

    public int getImagen() {
        return imagen;
    }
}
